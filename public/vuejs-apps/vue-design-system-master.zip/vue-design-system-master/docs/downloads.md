### These downloads, links, and third-party tools will help you and your teams learn, design, and build products. Here you can also provide links to assets like fonts, icons, color swatches, Sketch UI kits and so&nbsp;on.

You’re looking at Vue Design System’s demo downloads section. Everything you see here is editable in Markdown format. To change or remove this content, see [/docs/downloads.md](https://github.com/viljamis/vue-design-system/blob/master/docs/downloads.md).

## Vue Design System (zip)

- [Download latest version](https://github.com/viljamis/vue-design-system/archive/master.zip)
- [All versions](https://github.com/viljamis/vue-design-system/releases)
